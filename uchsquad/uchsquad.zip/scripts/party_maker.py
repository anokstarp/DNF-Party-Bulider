#!/usr/bin/env python3
import sqlite3
import pandas as pd
import numpy as np
import os
import random
import json
import argparse

# 1) DB에서 use_yn=1인 활성 캐릭터만 로드 (role 필터 옵션 추가)
def load_characters(db_path, role=None):
    """
    role: None (all), 'temple', 'azure', or 'venus'
    """
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found: {db_path}")
    conn = sqlite3.connect(db_path)
    base_query = """
        SELECT adventure, chara_name, job, fame, score, isbuffer
        FROM user_character
        WHERE use_yn = 1
    """
    if role in ('temple', 'azure', 'venus'):
        base_query += f" AND {role} = 1"
    df = pd.read_sql_query(base_query, conn)
    conn.close()
    return df

# 2) 점수 → 포인트 환산 및 버퍼/딜러 분리
def compute_points(df):
    bufs = df[df['isbuffer'] == 1].copy()
    dels = df[df['isbuffer'] == 0].copy()
    bufs['point'] = bufs['score'] / 3_000_000.0
    dels['point'] = (dels['score'] // 1_000_000) / 10.0
    return bufs.to_dict('records'), dels.to_dict('records')

# 3) 파티 생성 수 계산
def calc_party_count(buffers, dealers):
    total = len(buffers) + len(dealers)
    return min(len(buffers), total // 4)

# 4) 파티 스코어 편차 최소화를 위한 최적화 (완전 4인 대상)
def optimize_parties(parties, iterations=1000):
    def std(p_list):
        scores = [
            p['party_score']
            for p in p_list
            if len(p['buffers']) + len(p['dealers']) == 4
        ]
        return np.std(scores) if scores else 0

    best_std = std(parties)
    n = len(parties)
    for _ in range(iterations):
        if random.random() < 0.5:
            # 딜러 스왑
            i, j = random.sample(range(n), 2)
            p1, p2 = parties[i], parties[j]
            if not p1['dealers'] or not p2['dealers']:
                continue
            idx1 = random.randrange(len(p1['dealers']))
            idx2 = random.randrange(len(p2['dealers']))
            d1, d2 = p1['dealers'][idx1], p2['dealers'][idx2]
            advs1 = {b['adventure'] for b in p1['buffers']} | {d['adventure'] for d in p1['dealers']}
            advs2 = {b['adventure'] for b in p2['buffers']} | {d['adventure'] for d in p2['dealers']}
            if d2['adventure'] in advs1 or d1['adventure'] in advs2:
                continue
            p1['dealers'][idx1], p2['dealers'][idx2] = d2, d1
            swap_info = ('dealer', i, j, idx1, idx2, d1, d2)
        else:
            # 버퍼 스왑
            i, j = random.sample(range(n), 2)
            p1, p2 = parties[i], parties[j]
            b1, b2 = p1['buffers'][0], p2['buffers'][0]
            advs1 = {b['adventure'] for b in p1['buffers']} | {d['adventure'] for d in p1['dealers']}
            advs2 = {b['adventure'] for b in p2['buffers']} | {d['adventure'] for d in p2['dealers']}
            if b2['adventure'] in advs1 or b1['adventure'] in advs2:
                continue
            p1['buffers'][0], p2['buffers'][0] = b2, b1
            swap_info = ('buffer', i, j, b1, b2)

        for idx in (swap_info[1], swap_info[2]):
            p = parties[idx]
            buf_pts = sum(b['point'] for b in p['buffers'])
            deal_pts = sum(d['point'] for d in p['dealers'])
            p['party_score'] = buf_pts * deal_pts

        new_std = std(parties)
        if new_std < best_std:
            best_std = new_std
        else:
            # revert
            if swap_info[0] == 'dealer':
                _, i, j, idx1, idx2, od1, od2 = swap_info
                parties[i]['dealers'][idx1] = od1
                parties[j]['dealers'][idx2] = od2
            else:
                _, i, j, ob1, ob2 = swap_info
                parties[i]['buffers'][0], parties[j]['buffers'][0] = ob1, ob2
            for idx in (swap_info[1], swap_info[2]):
                p = parties[idx]
                buf_pts = sum(b['point'] for b in p['buffers'])
                deal_pts = sum(d['point'] for d in p['dealers'])
                p['party_score'] = buf_pts * deal_pts

    return parties

# 5) 파티 매칭
def match_parties(buffers, dealers):
    party_count    = calc_party_count(buffers, dealers)
    buffers_sorted = sorted(buffers, key=lambda x: x['point'], reverse=True)
    deals_desc     = sorted(dealers, key=lambda x: x['score'], reverse=True)
    deals_asc      = sorted(dealers, key=lambda x: x['score'])

    parties = []
    for i in range(party_count):
        parties.append({
            'buffers': [buffers_sorted[i]],
            'dealers': [],
            'advs':    {buffers_sorted[i]['adventure']}
        })

    # 5-1) 약한 버퍼 파티부터 강한 딜러 1명
    buf_weak_order = sorted(range(party_count),
                             key=lambda i: parties[i]['buffers'][0]['point'])
    for idx in buf_weak_order:
        for d in deals_desc[:]:
            if d['adventure'] not in parties[idx]['advs']:
                parties[idx]['dealers'].append(d)
                parties[idx]['advs'].add(d['adventure'])
                if d in deals_desc: deals_desc.remove(d)
                if d in deals_asc:  deals_asc.remove(d)
                break

    def max_dealer_score(p):
        return max((d['score'] for d in p['dealers']), default=0)

    # 5-2) 강한 딜러 >50억 파티에 약한 딜러 2명
    THRESH = 5_000_000_000
    order_strong = sorted(parties, key=max_dealer_score, reverse=True)
    for p in order_strong:
        if max_dealer_score(p) > THRESH:
            added = 0
            for d in deals_asc[:]:
                if d['adventure'] not in p['advs'] and len(p['dealers']) < 3:
                    parties[idx]['dealers'].append(d)
                    parties[idx]['advs'].add(d['adventure'])
                    if d in deals_asc:  deals_asc.remove(d)
                    if d in deals_desc: deals_desc.remove(d)
                    added += 1
                    if added == 2:
                        break

    # 5-3) 남는 버퍼 반복 배정 (dealer 자리로만 최대 1명)
    leftover_bufs = buffers_sorted[party_count:]
    for buf in leftover_bufs:
        for p in order_strong:
            if buf['adventure'] not in p['advs'] and \
               len(p['buffers']) + len(p['dealers']) < 4:
                p['dealers'].append(buf)
                p['advs'].add(buf['adventure'])
                p['_got_buffer_as_dealer'] = True
                break

    # 5-4) 남는 딜러 배정
    for d in deals_asc[:]:
        for p in order_strong:
            if d['adventure'] in p['advs'] or \
               len(p['buffers']) + len(p['dealers']) >= 4:
                continue
            if p.get('_got_buffer_as_dealer'):
                if deals_desc:
                    strong = deals_desc[0]
                    if strong['adventure'] not in p['advs']:
                        p['dealers'].append(strong)
                        p['advs'].add(strong['adventure'])
                        if strong in deals_desc: deals_desc.remove(strong)
                        if strong in deals_asc:  deals_asc.remove(strong)
                break
            else:
                p['dealers'].append(d)
                p['advs'].add(d['adventure'])
                if d in deals_asc:  deals_asc.remove(d)
                if d in deals_desc: deals_desc.remove(d)
                break

    # 스코어 계산 & 정리
    for p in parties:
        buf_pts  = sum(b['point'] for b in p['buffers'])
        deal_pts = sum(d['point'] for d in p['dealers'])
        p['sum_points']  = deal_pts
        p['party_score'] = buf_pts * deal_pts
        del p['advs']

    # 편차 최적화
    return optimize_parties(parties)

# 6) Flask용 래퍼: DB에 저장
def run_party_generation(role=None):
    # DB 경로
    script_dir   = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    db_path      = os.path.join(project_root, 'database', 'DB.sqlite')

    df       = load_characters(db_path, role)
    buffers, dealers = compute_points(df)
    parties  = match_parties(buffers, dealers)

    conn = sqlite3.connect(db_path)
    cur  = conn.cursor()
    type_val = role if role else 'all'
    cur.execute("DELETE FROM party WHERE type = ?", (type_val,))

    for p in parties:
        buf = p['buffers'][0]
        buf_json = json.dumps({
            'adventure': buf['adventure'],
            'chara_name': buf['chara_name'],
            'job': buf['job'],
            'fame': buf['fame'],
            'score': buf['score']
        }, ensure_ascii=False)

        dealer_jsons = []
        for d in p['dealers'][:3]:
            dealer_jsons.append(json.dumps({
                'adventure':   d['adventure'],
                'chara_name':  d['chara_name'],
                'job':         d['job'],
                'fame':        d['fame'],
                'score':       d['score']
            }, ensure_ascii=False))
        while len(dealer_jsons) < 3:
            dealer_jsons.append('')

        cur.execute(
            "INSERT INTO party(type, buffer, dealer1, dealer2, dealer3, result) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (type_val,
             buf_json,
             dealer_jsons[0], dealer_jsons[1], dealer_jsons[2],
             p['party_score'])
        )
    conn.commit()
    conn.close()

# 7) 콘솔 실행: DB 수정 없이 출력
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Generate & save parties (Flask use run_party_generation) or print to console')
    parser.add_argument(
        'role', nargs='?', choices=['temple','azure','venus'],
        default=None,
        help="Role filter (temple, azure, venus); omit for all")
    args = parser.parse_args()

    script_dir   = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    db_path      = os.path.join(project_root, 'database', 'DB.sqlite')

    df              = load_characters(db_path, args.role)
    buffers, dealers = compute_points(df)
    parties         = match_parties(buffers, dealers)

    for idx, p in enumerate(parties, start=1):
        buf = p['buffers'][0]
        print(f"Party {idx}:")
        print(f"  Buffer: {buf['adventure']} — {buf['chara_name']}, score: {buf['score']:,}")
        for di, d in enumerate(p['dealers'], start=1):
            print(f"  Dealer{di}: {d['adventure']} — {d['chara_name']}, score: {d['score']:,}")
        print(f"  Combined Score: {p['party_score']:.2f}\n")
