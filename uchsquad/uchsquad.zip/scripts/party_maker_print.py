#!/usr/bin/env python3
import sqlite3
import pandas as pd
import numpy as np
import os
import random
import argparse
import json

# 1) DB에서 use_yn=1인 활성 캐릭터만 로드 (role 필터 옵션 추가)
def load_characters(db_path, role=None):
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found: {db_path}")
    conn = sqlite3.connect(db_path)
    base_query = """
        SELECT adventure, chara_name, job, fame, score, isbuffer
        FROM user_character
        WHERE use_yn = 1
    """
    if role in ('temple', 'azure', 'venus'):
        base_query += f" AND {role} = 1"
    df = pd.read_sql_query(base_query, conn)
    conn.close()
    return df

# 2) 점수 → 포인트 환산 및 버퍼/딜러 분리
def compute_points(df):
    bufs = df[df['isbuffer'] == 1].copy()
    dels = df[df['isbuffer'] == 0].copy()
    bufs['point'] = bufs['score'] / 3_000_000.0
    dels['point'] = (dels['score'] // 1_000_000) / 10.0
    return bufs.to_dict('records'), dels.to_dict('records')

# 3) 파티 생성 수 계산
def calc_party_count(buffers, dealers):
    total = len(buffers) + len(dealers)
    return min(len(buffers), total // 4)

# 4) 편차 줄이기 위한 최적화 (생략, 그대로 둠)
def optimize_parties(parties, iterations=1000):
    def std(p_list):
        scores = [p['party_score'] for p in p_list if len(p['buffers']) + len(p['dealers']) == 4]
        return np.std(scores) if scores else 0

    best_std = std(parties)
    n = len(parties)
    for _ in range(iterations):
        # ... (기존 최적화 로직 그대로)
        pass
    return parties

# 5) 파티 매칭
def match_parties(buffers, dealers):
    party_count    = calc_party_count(buffers, dealers)
    buffers_sorted = sorted(buffers, key=lambda x: x['point'], reverse=True)
    deals_desc     = sorted(dealers, key=lambda x: x['score'], reverse=True)
    deals_asc      = sorted(dealers, key=lambda x: x['score'])

    # 초기화: 메인 버퍼 1명
    parties = []
    for i in range(party_count):
        parties.append({
            'buffers': [buffers_sorted[i]],
            'dealers': [],
            'advs':    {buffers_sorted[i]['adventure']}
        })

    # 5-1) 약한 버퍼 파티부터 강한 딜러 1명
    buf_weak_order = sorted(range(party_count),
                             key=lambda i: parties[i]['buffers'][0]['point'])
    for idx in buf_weak_order:
        for d in deals_desc[:]:
            if d['adventure'] not in parties[idx]['advs']:
                parties[idx]['dealers'].append(d)
                parties[idx]['advs'].add(d['adventure'])
                deals_desc.remove(d)
                deals_asc.remove(d)
                break

    # 5-2) 강한 딜러 >50억 파티에 약한 딜러 2명
    TH = 5_000_000_000
    def max_dealer_score(p):
        return max((d['score'] for d in p['dealers']), default=0)
    order_strong = sorted(parties, key=max_dealer_score, reverse=True)
    for p in order_strong:
        if max_dealer_score(p) > TH:
            cnt = 0
            for d in deals_asc[:]:
                if d['adventure'] not in p['advs']:
                    p['dealers'].append(d)
                    p['advs'].add(d['adventure'])
                    deals_asc.remove(d)
                    deals_desc.remove(d)
                    cnt += 1
                    if cnt == 2:
                        break

    # 5-3) 남는 버퍼 → 다음 강한 파티 순으로 1명씩
    leftover_bufs = buffers_sorted[party_count:]
    for buf in leftover_bufs:
        for p in order_strong:
            if buf['adventure'] not in p['advs'] and len(p['buffers']) + len(p['dealers']) < 4:
                p['dealers'].append(buf)
                p['advs'].add(buf['adventure'])
                p['_got_buffer_as_dealer'] = True
                break

    # 5-4) 남는 딜러 배정 — 반복하여 가능한 모든 파티에 채워넣고, 더 이상 배정 불가 시 종료
    while True:
        assigned = False
        for p in order_strong:
            if len(p['buffers']) + len(p['dealers']) >= 4:
                continue
            # 버퍼 대신 들어간 파티에는 강한 딜러, 아니면 약한 딜러
            pool = deals_desc if p.get('_got_buffer_as_dealer') else deals_asc
            for d in pool:
                if d['adventure'] not in p['advs']:
                    p['dealers'].append(d)
                    p['advs'].add(d['adventure'])
                    # 두 리스트에서 제거
                    if d in deals_asc:  deals_asc.remove(d)
                    if d in deals_desc: deals_desc.remove(d)
                    assigned = True
                    break
        if not assigned:
            break

    # 스코어 계산 & advs 정리
    for p in parties:
        buf_pts  = sum(b['point'] for b in p['buffers'])
        deal_pts = sum(d['point'] for d in p['dealers'])
        p['party_score'] = buf_pts * deal_pts
        del p['advs']

    # 6) 편차 최적화
    return optimize_parties(parties)

# 7) 메인 실행부: 콘솔 출력 & DB 삽입
if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='Generate parties, print and insert into DB')
    parser.add_argument('role', nargs='?', choices=['temple','azure','venus'],
                        default=None, help="Role filter")
    args = parser.parse_args()

    # DB 경로
    base = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(base, '..', 'database', 'DB.sqlite')

    # 캐릭터 로드 & 포인트 계산
    df = load_characters(db_path, args.role)
    buffers, dealers = compute_points(df)
    print(f"Loaded: total={len(buffers)+len(dealers)} "
          f"(buffers={len(buffers)}, dealers={len(dealers)})")

    # 파티 생성
    parties = match_parties(buffers, dealers)

    # 콘솔 출력
    for i,p in enumerate(parties,1):
        b = p['buffers'][0]
        print(f"Party {i}: Buffer: {b['adventure']}—{b['chara_name']}({b['score']:,})")
        for j,d in enumerate(p['dealers'],1):
            print(f"  Dealer{j}: {d['adventure']}—{d['chara_name']}({d['score']:,})")
        print(f"  Combined: {p['party_score']:.2f}\n")

    # 남아있는 캐릭터
    assigned = {tuple(x.items()) for p in parties for x in (p['buffers']+p['dealers'])}
    all_ch = buffers + dealers
    unassigned = [c for c in all_ch if tuple(c.items()) not in assigned]
    print("=== Unassigned ===")
    for c in unassigned:
        role_lbl = "버퍼" if c['isbuffer']==1 else "딜러"
        print(f"[{role_lbl}] {c['adventure']}—{c['chara_name']}({c['score']:,})")
    print(f"총 {len(unassigned)}명 남음\n")

    # DB 삽입
    conn = sqlite3.connect(db_path)
    cur  = conn.cursor()
    tval = args.role or 'all'
    cur.execute("DELETE FROM party WHERE type = ?", (tval,))
    for p in parties:
        buf = p['buffers'][0]
        buf_j = json.dumps({k: buf[k] for k in ('adventure','chara_name','job','fame','score')}, ensure_ascii=False)
        dj = []
        for d in p['dealers'][:3]:
            dj.append(json.dumps({k: d[k] for k in ('adventure','chara_name','job','fame','score')}, ensure_ascii=False))
        dj += ['']*(3-len(dj))
        cur.execute("INSERT INTO party(type,buffer,dealer1,dealer2,dealer3,result) VALUES(?,?,?,?,?,?)",
                    (tval, buf_j, dj[0], dj[1], dj[2], p['party_score']))
    conn.commit()
    conn.close()
    print(f"→ DB에 {len(parties)}개 파티 저장 완료 (type={tval})")
