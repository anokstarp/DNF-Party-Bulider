import os
import json
import subprocess
from flask import Blueprint, render_template, request, redirect, url_for
from app import get_db_connection

party_bp = Blueprint('party', __name__, url_prefix='/party')

@party_bp.route('/', methods=['GET', 'POST'])
def list_and_generate():
    # 역할 파라미터(temple 또는 dealer)에 따라 파티 생성과 조회를 처리
    role = request.values.get('role', 'temple')

    if request.method == 'POST':
        # party_maker_print.py 실행하여 DB 업데이트
        base_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        script_path = os.path.join(base_dir, 'scripts', 'party_maker_print.py')
        subprocess.run(['python', script_path, role], check=True)
        return redirect(url_for('party.list_and_generate', role=role))

    # GET 요청: DB에서 파티 목록 조회
    conn = get_db_connection()
    query = (
        "SELECT id, type, buffer, dealer1, dealer2, dealer3, result "
        "FROM party WHERE type = ? ORDER BY id ASC"
    )
    rows = conn.execute(query, (role,)).fetchall()
    conn.close()

    # JSON 직렬화된 컬럼을 Python 객체로 변환하여 리스트 구성
    parties = []
    for row in rows:
        buffer_obj = json.loads(row['buffer']) if row['buffer'] else None
        dealers = [
            json.loads(row['dealer1']) if row['dealer1'] else None,
            json.loads(row['dealer2']) if row['dealer2'] else None,
            json.loads(row['dealer3']) if row['dealer3'] else None,
        ]
        parties.append({
            'id': row['id'],
            'type': row['type'],
            'buffer': buffer_obj,
            'dealers': dealers,
            'result': row['result'],
        })

    return render_template('party.html', selected=role, parties=parties)
